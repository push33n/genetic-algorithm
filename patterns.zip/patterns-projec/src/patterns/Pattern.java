package patterns;

import java.util.ArrayList;

import patterns.shapes.Diamond;
import patterns.shapes.House;
import patterns.shapes.Petal;
import patterns.shapes.Square;
import patterns.shapes.Triangle;

public class Pattern implements Comparable{
	public static ArrayList<String> availableshapes=new ArrayList<String>();
	private int[][]output;
	private ArrayList<Shape> shapes;
	private int[] numshapes; /*number of each type of shape in this pattern, 
in order of availableshapes*/
	private int totalshapes; /*sum of all numbers in numshapes*/
	private ArrayList<int[]> startindices; /* type of shape, start x, start y*/
	public Pattern()
	{
		//initialzie output grid
		output= new int[50][50];
		for(int row=0; row<50; row++)
		{for(int col=0; col<50; col++)
		{
			output[row][col]=0;
		}}
		//initialize instance variables
		availableshapes.add("Square");
		availableshapes.add("Diamond");
		availableshapes.add("House");
		availableshapes.add("Petal");
		availableshapes.add("Triangle");
		shapes= new ArrayList<Shape>();
		numshapes= new int[availableshapes.size()];
		totalshapes=0;
		startindices=new ArrayList<int[]>();

		//add patterns to output grid
		for(int i=0; i<10; i++)
		{
			add();
		}
	}
	public String print() 
	{
		String pattern = "";
		for (int row = 0; row < output.length; row++) {
			for (int col = 0; col < output[0].length; col++) {
				pattern += output[row][col];
				pattern +=" ";
			}
			pattern += "\n";
		}
		return pattern;
	}
	//altering methods
	public void add()
	{
		//put shape in output and shape array
		Shape s=shapegenerator((int)(Math.random() *availableshapes.size()), (int)(Math.random()*31));
		s.place(getOutput());
		shapes.add(s);
		//update numshapes
		if(s.getType().equals("Square"))
			numshapes[0]+=1;
		else if (s.getType().equals("Diamond"))
			numshapes[1]+=1;
		else if (s.getType().equals("House"))
			numshapes[2]+=1;
		else if (s.getType().equals("Petal"))
			numshapes[3]+=1;
		else
			numshapes[4]+=1;
		//update totalshapes
		totalshapes+=1;
		//update startindecis
		int[]indeces= new int[2];
		indeces[0]=s.startrow;
		indeces[1]=s.startcol;
		startindices.add(indeces);

	}
	public void add(Shape s)
	{
		s.place(getOutput());
		shapes.add(s);
		//update numshapes
		if(s.getType().equals("Square"))
			numshapes[0]+=1;
		else if (s.getType().equals("Diamond"))
			numshapes[1]+=1;
		else if (s.getType().equals("House"))
			numshapes[2]+=1;
		else if (s.getType().equals("Petal"))
			numshapes[3]+=1;
		else
			numshapes[4]+=1;
		//update totalshapes
		totalshapes+=1;
		//update startindecis
		int[]indeces= new int[2];
		indeces[0]=s.startrow;
		indeces[1]=s.startcol;
		startindices.add(indeces);
	}
	public void remove()
	{
		int index=(int)Math.random()*shapes.size();
		shapes.get(index).remove(output);
	}
	
	public void set(Pattern p)
	{
		output=p.getOutput();
		shapes=p.getShapes();
		numshapes=p.getNumShapes();
		totalshapes=p.getTotalShapes();
		 startindices=p.getStartIndices();
	}
	
	//ranking methods
	public double rank()
	{
		return 0-this.getSymetry()+this.getComplexity() + 0.75*this.getDiversity();	
	}
	
	public int compareTo(Object p)
	{
		if(!p.getClass().equals(this.getClass()))
			throw new RuntimeException("wrong class");
		if(((Pattern) p).rank()>this.rank())
			return -1;
		else if(((Pattern) p).rank()<this.rank())
			return 1;
		else
			return 0;
	}
	//assistant methods
	public String toString() 
	{
		String returnedstring = "";
		for (int row = 0; row < output.length; row++) {
			for (int col = 0; col < output[0].length; col++) {
				returnedstring += output[row][col];
			returnedstring +=" ";
			}
			returnedstring += "\n";
		}
		return returnedstring;
	}
	public Shape shapegenerator(int index, int size)
	{
		if(index==0)
			return new Square(size);
		else if(index==1)
			return new Diamond(size);
		else if (index==2)
			return new House(size);
		else if (index==3)
			return new Petal(size);
		else 
			return new Triangle(size);

	}
	public double getSymetry()
	{
		return getVS()+getHS();
	}
	
	public double getComplexity() //number of 1s compared to number of 0s; 65% is max for ones
	{
		double totalsquares=output.length+output[0].length;
		double onesquares=0;
		for(int row=0; row<output.length; row++)
		{for(int col=0; col<output[0].length; col++)
			if(output[row][col]==1)
				onesquares+=1;
		}
		double percentage=100*(onesquares/totalsquares);
		double complexity=5+(Math.pow(percentage-60, 2)/-320);
		return complexity;
	}
	public double getDiversity()
	{
		double standev=getStanDev(numshapes);
		return -standev;
	}

	//assistant to the assistant methods
	public double getVS()
	{
		int vs=0;
		for(int row=0; row<output.length; row++)
		{for(int col=0; col<output[0].length/2; col++)
			if(output[row][col]==output[row][output[0].length-col-1])
				vs+=1;
		}
		double percentage=100*vs/25;
		return 3.5*percentage/100;
	}
	public double getHS()
	{
		int hs=0;
		for(int row=0; row<output.length/2; row++)
		{for(int col=0; col<output[0].length; col++)
			if(output[row][col]==output[output.length-row-1][col])
				hs+=1;
		}
		double percentage=100*hs/25;
		return 3.5*percentage/100;
	}
public static double getStanDev(int[] nums)
{
	double average=0;
	double[] newnums= new double[nums.length];
	double output=0;
	for(int i=0; i<nums.length; i++)
	{
		average+=nums[i];
	}
	average/=nums.length;
	for(int i=0; i<nums.length; i++)
	{
		newnums[i]=Math.pow(nums[i]-average, 2);
	}
	for(int i=0; i<newnums.length; i++)
	{
		output+=newnums[i];
	}
	output/=newnums.length;
	output=Math.pow(output, 0.5);
	return output;
}
//getter methods

public int[][] getOutput()
{
	return output;	
}
public ArrayList<Shape> getShapes()
{
return shapes;	
}
public int[] getNumShapes()
{
return numshapes;	
}
public int getTotalShapes()
{
	return totalshapes;	
}
public ArrayList<int[]> getStartIndices()
{
return startindices;	
}
}