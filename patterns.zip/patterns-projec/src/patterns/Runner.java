package patterns;

import patterns.shapes.Diamond;
import patterns.shapes.House;
import patterns.shapes.Petal;
import patterns.shapes.Square;
import patterns.shapes.Triangle;

public class Runner {
	public static String parseArray(int[][] array) {
		String output = "";
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[0].length; col++) {
				output += array[row][col];
				output +=" ";
			}
			output += "\n";
		}
		return output;
	}

	public static void main(String[] args) {
		int[][] grid = new int[25][25];
		for (int row = 0; row < 25; row++) {
			for (int col = 0; col < 25; col++) {
				 grid[row][col] = 0;
			}
		}
		
		Evolution e= new Evolution();
		e.evolve();
		e.evolve();
		e.evolve();
		Pattern p= new Pattern();
		Square s= new Square(5);
		p.add(s);
		
		System.out.print(p);
	
		
		

		
	}
}
