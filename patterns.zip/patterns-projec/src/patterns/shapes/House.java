package patterns.shapes;

import patterns.Shape;

public class House extends Shape{
	private int size;
	private int[][] myborders;
	public House(int s)
	{
		super(2+4*s);
		size=s;
		startcol=0;
		startrow=0;
		myborders=super.getBorders();
	}


	public void updateBorders(int[][] here) /*updates borders and modifies pattern*/
	{
		//initialize startcol and startrow
		while(startcol<size)
		{
		startcol=(int)(here[0].length*Math.random());}
	
		while(startrow<size)
		startrow=(int)(here.length*Math.random()); 
		
		myborders[0][0]=startrow;
		myborders[0][1]=startcol;
	//place 1s in pattern
		here[startrow][startcol]=1;
		int currentx=startcol;
		int currenty=startrow;
		currenty=goUp(here, 1, currentx, currenty, 1)+1;
		goDiagRight(here, size, currentx, currenty, 2);
		currentx=goRight(here, 2*size, startcol, startrow, 2+size);
		goUp(here, 1, currentx-1, currenty+1, 2+3*size);
		goDiagLeft(here, size-1, currentx-1, currenty,3+(3*size));
		
		}

	public String getType()
	{
		return "House";
	}
	}


