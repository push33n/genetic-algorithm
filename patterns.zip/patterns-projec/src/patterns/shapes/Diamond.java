package patterns.shapes;

import patterns.Shape;

public class Diamond extends Shape{
	private int size;
	private int[][] myborders;
public Diamond(int s)
{
	
	super(4*s);
	size=s;
	myborders=super.getBorders();
}


public void updateBorders(int[][] here) /*updates borders and modifies pattern*/
{
	
	while(super.getStartCol()<size)
	{
	super.setStartCol((int)(here[0].length*Math.random()));}

	while(super.getStartRow()<size)
	{super.setStartRow((int)(here[0].length*Math.random()));}
	
	
	
	
	here[startrow][startcol]=1;
	int currentx=startcol;
	int currenty=startrow;
	int[]newcor=goDiagRight(here, size, currentx, currenty, 1);
	currentx=newcor[0];
	currenty=newcor[1];
	goDiagLeft(here, size, currentx-1, currenty+1, 1+size);
	newcor=goDiagLeft(here, size, startcol, startrow, 1+(2*size));
	currentx=newcor[0];
	currenty=newcor[1];
	goDiagRight(here, size-1, currentx+1, currenty+1, 1+(3*size));
	}

public String getType()
{
	return "Diamond";
}
}
