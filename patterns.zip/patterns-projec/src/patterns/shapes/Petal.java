package patterns.shapes;

import patterns.Shape;

public class Petal extends Shape {
	private int size;
	private int[][] myborders;
	
	public Petal(int s)
	{
		super(4*(s+1));
		size=s;
		startcol=0;
		startrow=0;
		myborders=super.getBorders();
	}


	public void updateBorders(int[][] here) /*updates borders and modifies pattern*/
	{
		//initialize startcol and startrow
		while(super.getStartCol()<size)
		{
		super.setStartCol((int)(here[0].length*Math.random()));}

		while(super.getStartRow()<size)
		{super.setStartRow((int)(here[0].length*Math.random()));}

		
		
		here[startrow][startcol]=1;
		int currentx=startcol;
		int currenty=startrow;
			int[] currentn=goDiagLeft(here, 1, currentx, currenty, 1);
			currentx=currentn[0]+1;
			currenty=currentn[1];
		currenty=goUp(here, size, currentx, currenty+1, 2);
			currentn=goDiagRight(here, 1, currentx, currenty+1, 2+size);
			currentx=currentn[0]-1;
			currenty=currentn[1]+1;
		goRight(here, size, currentx, currenty,3+size) ;
		currentx=goRight(here, size, startcol, startrow, 3+2*size)-1;
		currentn=goDiagRight(here, 1, currentx, startrow, 3+3*size);
			currentx=currentn[0]-1;
			currenty=currentn[1]+1;
		goUp(here, size, currentx, currenty, 4+3*size);
		
		}

	public String getType()
	{
		return "Petal";
	}
}
