package patterns.shapes;

import patterns.Shape;

public class Triangle extends Shape{
	
	private int size;
	private int[][] myborders;
	
	
	public Triangle(int vertices)
	{
		super(4*vertices);
		size=vertices;
		
		myborders=new int[size][2];
	}


	public void updateBorders(int[][] here) /*updates borders and modifies pattern*/
	{
		
		//initialize startcol and startrow
		while(super.getStartCol()<size)
		{
		super.setStartCol((int)(here[0].length*Math.random()));}

		while(super.getStartRow()<size)
		{super.setStartRow((int)(here[0].length*Math.random()));}
		
		//*myborders[0][0]=startrow;
		//*myborders[0][1]=startcol;
		
		
		here[startrow][startcol]=1;
		int currentx=startcol;
		int currenty=startrow;
		
		int[] currentn=goDiagRight(here, size, startcol, startrow, 1);
		currentx=currentn[0]-1;
		currenty=currentn[1]+1;
		currentx=goRight(here, 2* size, startcol, startrow, 1+size)-1;
		goDiagLeft(here, size-1, currentx, startrow,1+3*size);
		}

	public String getType()
	{
		return "Triangle";
	}
}
