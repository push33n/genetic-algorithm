package patterns.shapes;

import patterns.Shape;

public class Square extends Shape{
	private int size;
	private int[][] myborders;
	
public Square(int s)
{
	super(4*s);
	size=s;
	startcol=0;
	startrow=0;
	borders= new int[size][2];
}


public void updateBorders(int[][] here) /*updates borders and modifies pattern*/
{
	myborders=super.getBorders();
	//initialize startcol and startrow
	while(super.getStartCol()<size)
	{
	super.setStartCol((int)(here[0].length*Math.random()));}

	while(super.getStartRow()<size)
	{super.setStartRow((int)(here[0].length*Math.random()));}



	
	here[startrow][startcol]=1;
	int currentx=startcol;
	int currenty=startrow;
	currenty=goUp(here, size, currentx, currenty, 1);
	
	goRight(here, size, currentx, currenty+1, 1+size);
	currentx=goRight(here, size, startcol, startrow, 1+(2*size));
	goUp(here, size-1, currentx-1, startrow,1+(3*size));
	}

public String getType()
{
	return "Square";
}
}
