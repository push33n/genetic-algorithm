package patterns;
public abstract class Shape {
	
	protected int[][]borders /*placement indices in pattern*/;
	protected  int startrow;
	protected  int startcol;
	
	public Shape(int vertices)
	{
		borders= new int[vertices][2];
		startcol=0;
		startrow=0;
		System.out.println(vertices/4);
		
	}
	public int[][] getBorders()
	{
		return borders;
	}
	public int getStartCol()
	{
		return startcol;
	}
	public int getStartRow()
	{
		return startrow;
	}
	public void setStartCol(int i)
	{
		startcol=i;
		borders[0][1]=startcol;
	}
	public void setStartRow(int i)
	{
		startrow=i;
		borders[0][0]=startcol;
	}
	public void place(int[][] here)
	{
		
		updateBorders(here);
		
	}
	public void remove(int[][] grid)
	{
		for(int pair=0; pair<50; pair++)
		{
			for(int col=0; col<50; col++)
				grid[pair][col]=0;
		}
	}
	public int goUp (int[][]here, int sizee, int scol, int srow, int bc)
	{
		int myy=srow-1;
	int bordercount=bc;
	int siz=sizee;
	while(myy>-1 && siz>0)
	{	
		
		if(here[myy][scol]==0 &&bordercount<borders.length)
				{here[myy][scol]=1;
				borders[bordercount][1]=scol;
				borders[bordercount][0]=myy;
				bordercount+=1;
				siz-=1;}
			myy-=1;
			
	}
	return myy;
	}
	public int goRight (int[][]here, int sizee, int scol, int srow, int bc)
	{
	
	int myx=scol+1;
	int bordercount=bc;
	int siz=sizee;
	while(myx<here[0].length && siz>0)
	{
			if(bordercount<borders.length&&here[srow][myx]==0)
				{here[srow][myx]=1;
				borders[bordercount][1]=myx;
				borders[bordercount][0]=srow;
				bordercount+=1;
				siz-=1;}
			myx+=1;
			
	}
	return myx;
	}
	public int[] goDiagRight (int[][]here, int sizee, int scol, int srow, int bc)
	{
	int myx=scol+1;
	int myy=srow-1;
	int bordercount=bc;
	int siz=sizee;
	while(myy>=0 && myx<here[0].length && siz>0)
	{
			if(here[myy][myx]==0)
				{here[myy][myx]=1;
				borders[bordercount][1]=myx;
				borders[bordercount][0]=myy;
				bordercount+=1;
				siz-=1;}
			myx+=1;
			myy-=1;	
	}
	int[] output= new int[2];
	output[0]=myx;
	output[1]=myy;
	return output;
	}
public int[] goDiagLeft (int[][]here, int sizee, int scol, int srow, int bc)
	{
	int myx=scol-1;
	int myy=srow-1;
	int bordercount=bc;
	int siz=sizee;
	while(myy>=0 && myx>=0 && siz>0)
	{
			if(here[myy][myx]==0)
				{here[myy][myx]=1;
				borders[bordercount][1]=myx;
				borders[bordercount][0]=myy;
				bordercount+=1;
				siz-=1;}
			myx-=1;
			myy-=1;	
	}
	int[] output={myx, myy};
	return output;
	}
	public abstract void updateBorders(int[][]here);
	public abstract String getType();
		
	}
	


