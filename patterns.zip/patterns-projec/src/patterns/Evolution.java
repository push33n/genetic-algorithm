package patterns;

import java.util.ArrayList;
import java.util.PriorityQueue;

import patterns.shapes.Square;

public class Evolution {
	private PriorityQueue<Pattern> mypatterns;
	public Evolution()
	{
		mypatterns=new PriorityQueue<Pattern>();
		PriorityQueue<Pattern> starters= new PriorityQueue<Pattern>();
		for(int i=0; i<20; i++)
			{System.out.println(starters.size());
			Pattern p=new Pattern();
			p.add(new Square(5));
			starters.add(p);}
		for(int i=0; i<10; i++)
			mypatterns.add(starters.remove());
	}
//this is what this does
	public void evolve()
{
	int size=mypatterns.size()-2;
	PriorityQueue<Pattern> updatedpatterns= new PriorityQueue<Pattern>();
	for(int index=0; index<size; index++)
	{	double threshold=Math.random();
		Pattern newpattern= new Pattern();
		newpattern.set(mypatterns.peek());
		if(threshold<0.75)
			newpattern.add();
		else
			newpattern.remove();
		if(newpattern.compareTo(mypatterns.peek())>=0)
			updatedpatterns.add(newpattern);
		else
			updatedpatterns.add(mypatterns.peek());
		mypatterns.remove();
		
			
	}
	updatedpatterns.add(new Pattern());
	updatedpatterns.add(new Pattern());
	mypatterns=updatedpatterns;
	
		
}
public String printbest()
{
return mypatterns.peek().print();	
}
}
